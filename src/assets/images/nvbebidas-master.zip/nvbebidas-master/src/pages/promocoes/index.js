import './index.scss'

import cheddar from '../../assets/images/cheddar.png';
import onion from '../../assets/images/onion.png';
import duplo from '../../assets/images/duplo.png';
import vegano from '../../assets/images/vegano.png';
import logooo from '../../assets/images/logonv.png';
import fundo2 from '../../assets/images/fundo2.svg'

export default function promocoes() {
    return(
        <div className='pai'>

            <div className='cabecalho1'>

            <h1> CONHEÇA NOSSAS <br>
            </br>PROMOÇÕES </h1>
            </div>
            
            <div className='secao02'>
                
            </div>
        

        </div>
    );
}

       

           