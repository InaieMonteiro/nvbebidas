import './index.scss'




export default function() {
    return(
        <div className='uau'>

        <div className='nomezin'>
           <div className=''>
            <h1>40</h1>
            <h2>opcões irresistiveis</h2>
            </div>
            <div> <h1>60 mil</h1>
            <h2>hamburguers em 2023</h2>
            </div>
            <div className=''> <h1>12 mil</h1>
            <h2>clientes em 2023</h2>
            </div>
            
        </div>




        </div>
    )
} 



