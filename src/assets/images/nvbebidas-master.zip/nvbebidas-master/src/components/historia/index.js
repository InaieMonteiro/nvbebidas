import logo from '../../assets/images/logo.png'
import './index.scss';


export default function() {

    return(


        <div className='texto'>

        <img id='oie' src={logo}></img>

<h1>conheca nossa correria</h1>
<h2>Nós da THE RUNNERS BURGUERS, Nascemos <br></br> com uma proposta diferente. <br></br>
nascemos com o proposito de representar o <br></br> corre de cada um de nós no dia a dia, com <br></br> lanches com uma proposta artesanal. e <br></br> trazendo o nosso diferencial, que são os <br></br> nossos lanches veganos, agregando valor a <br></br> todos os gostos.</h2>

        </div>
    )
}