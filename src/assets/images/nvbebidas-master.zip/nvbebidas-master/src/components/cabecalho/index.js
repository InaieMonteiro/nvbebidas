import './index.scss'


<div className='pag-inicial'>

<div className='cabeca'>
           <a ><strong><span>SOBRE NÓS</span></strong></a>
           <a ><strong><span>HOME</span></strong></a>
             <a href='http://localhost:3000/batata'><strong><span>CARDÁPIO</span></strong></a>
          <a><strong><span>COMBOS</span></strong></a>
          <a><strong><span>PROMOÇÕES DA SEMANA</span></strong></a>
       </div>
    </div>